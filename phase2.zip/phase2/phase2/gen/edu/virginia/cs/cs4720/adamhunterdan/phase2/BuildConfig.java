/** Automatically generated file. DO NOT MODIFY */
package edu.virginia.cs.cs4720.adamhunterdan.phase2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}