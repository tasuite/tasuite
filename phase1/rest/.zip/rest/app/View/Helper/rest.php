<?php
	class RestHelper extends Helper
	{
	}
?>
