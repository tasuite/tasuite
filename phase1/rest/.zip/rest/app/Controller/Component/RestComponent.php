<?php 
class RestComponent extends Object {
}
?>
